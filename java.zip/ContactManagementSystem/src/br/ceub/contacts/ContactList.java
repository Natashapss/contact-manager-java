package br.ceub.contacts;

public class ContactList {
	 // Declare uma variável para representar o primeiro nó (head) da lista encadeada.
    private Node head;
    // Implemente o método addContact(Contact contact) para adicionar um novo contato ao final da lista.
    public void addContact(Contact contact) {
        Node newNode = new Node(contact);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
        System.out.println("Contato adicionado com sucesso!");
    }
    // Implemente o método searchContact(String nameOrPhone) para buscar um contato pelo nome ou número de telefone.
    public Contact searchContact(String keyword) {
        Node current = head;
        while (current != null) {
            if (current.contact.getName().equalsIgnoreCase(keyword) || current.contact.getPhoneNumber().equals(keyword)) {
                return current.contact;
            }
            current = current.next;
        }
        System.out.println("Contato não encontrado!");
        return null;
    }
    // Implemente o método removeContact(String nameOrPhone) para remover um contato pelo nome ou número de telefone.
    public boolean removeContact(String keyword) {
        if (head == null) {
            System.out.println("Lista de contatos vazia.");
            return false;
        }

        if (head.contact.getName().equalsIgnoreCase(keyword) || head.contact.getPhoneNumber().equals(keyword)) {
            head = head.next;
            System.out.println("Contato removido com sucesso.");
            return true;
        }

        Node current = head;
        while (current.next != null) {
            if (current.next.contact.getName().equalsIgnoreCase(keyword) || current.next.contact.getPhoneNumber().equals(keyword)) {
                current.next = current.next.next;
                System.out.println("Contato removido com sucesso.");
                return true;
            }
            current = current.next;
        }

        System.out.println("Contato não encontrado.");
        return false;
    }
    // Implemente o método listContacts() para exibir todos os contatos armazenados na lista.
    public void listContacts() {
        if (head == null) {
            System.out.println("Lista de contatos vazia.");
            return;
        }

        Node current = head;
        while (current != null) {
            System.out.println(current.contact);
            current = current.next;
        }
    }
}


