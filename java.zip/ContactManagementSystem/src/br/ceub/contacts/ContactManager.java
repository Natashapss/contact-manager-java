package br.ceub.contacts;

import java.util.Scanner;

public class ContactManager {
    public static void main(String[] args) {
        ContactList contactList = new ContactList();
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n--- Gerenciamento de Contatos ---");
            System.out.println("1. Adicionar Contato");
            System.out.println("2. Buscar Contato");
            System.out.println("3. Remover Contato");
            System.out.println("4. Listar Todos os Contatos");
            System.out.println("5. Sair");
            System.out.print("Escolha uma opção: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Limpar buffer

            switch (choice) {
                case 1:
                    System.out.print("Nome: ");
                    String name = scanner.nextLine();
                    System.out.print("Número de Telefone: ");
                    String phoneNumber = scanner.nextLine();
                    System.out.print("Email: ");
                    String email = scanner.nextLine();
                    Contact newContact = new Contact(name, phoneNumber, email);
                    contactList.addContact(newContact);
                    break;

                case 2:
                    System.out.print("Digite o nome ou número de telefone: ");
                    String searchKeyword = scanner.nextLine();
                    Contact foundContact = contactList.searchContact(searchKeyword);
                    if (foundContact != null) {
                        System.out.println("Contato encontrado: " + foundContact);
                    }
                    break;

                case 3:
                    System.out.print("Digite o nome ou número de telefone do contato a ser removido: ");
                    String removeKeyword = scanner.nextLine();
                    contactList.removeContact(removeKeyword);
                    break;

                case 4:
                    contactList.listContacts();
                    break;

                case 5:
                    System.out.println("Saindo...");
                    break;

                default:
                    System.out.println("Opção inválida.");
            }
        } while (choice != 5);

        scanner.close();
    }
}
